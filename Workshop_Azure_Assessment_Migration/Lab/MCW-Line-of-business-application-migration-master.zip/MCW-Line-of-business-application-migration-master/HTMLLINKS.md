﻿# HTML Files for Workshop
[WDS student guide - Line-of-business application migration.html](https://cloudworkshop.blob.core.windows.net/lob-application-migration/Whiteboard%20design%20session/WDS%20student%20guide%20-%20Line-of-business%20application%20migration.html)

[WDS trainer guide - Line-of-business application migration.html](https://cloudworkshop.blob.core.windows.net/lob-application-migration/Whiteboard%20design%20session/WDS%20trainer%20guide%20-%20Line-of-business%20application%20migration.html)

[Before the HOL - Line-of-business application migration.html](https://cloudworkshop.blob.core.windows.net/lob-application-migration/Hands-on%20lab/Before%20the%20HOL%20-%20Line-of-business%20application%20migration.html)

[HOL step-by step - Line-of-business application migration.html](https://cloudworkshop.blob.core.windows.net/lob-application-migration/Hands-on%20lab/HOL%20step-by%20step%20-%20Line-of-business%20application%20migration.html)

